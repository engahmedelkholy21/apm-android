package com.example.apmmanage;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.apmmanage.SalesAdapter;
import com.example.apmmanage.databinding.ActivityAllSalesBinding;
import com.example.apmmanage.SalesViewModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SalesActivity extends AppCompatActivity {
    private ActivityAllSalesBinding binding;
    private SalesViewModel viewModel;
    private SalesAdapter adapter;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private Date startDate = new Date();
    private Date endDate = new Date();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAllSalesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupViewModel();
        setupRecyclerView();
        setupSpinner();
        setupDatePickers();
        setupSearchListener();
        observeViewModel();
    }

    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(SalesViewModel.class);
    }

    private void setupRecyclerView() {
        adapter = new SalesAdapter();
        binding.salesRecyclerView.setAdapter(adapter);
        binding.salesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupSpinner() {
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Date Range", "Customer", "Product", "Category"});
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.searchTypeSpinner.setAdapter(spinnerAdapter);
    }

    private void setupDatePickers() {
        binding.startDateInput.setOnClickListener(v -> showDatePicker(true));
        binding.endDateInput.setOnClickListener(v -> showDatePicker(false));
    }

    private void setupSearchListener() {
        binding.searchInput.setOnEditorActionListener((v, actionId, event) -> {
            performSearch();
            return true;
        });
    }

    private void showDatePicker(boolean isStartDate) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(year, month, dayOfMonth);
                    if (isStartDate) {
                        startDate = selectedDate.getTime();
                        binding.startDateInput.setText(dateFormat.format(startDate));
                    } else {
                        endDate = selectedDate.getTime();
                        binding.endDateInput.setText(dateFormat.format(endDate));
                    }
                    performSearch();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void performSearch() {
        String searchType = binding.searchTypeSpinner.getSelectedItem().toString();
        String searchValue = binding.searchInput.getText().toString();
        String stock = "DEFAULT_STOCK"; // Replace with actual stock selection

        if (searchType.equals("Date Range")) {
            viewModel.loadSalesByDateRange(startDate, endDate, stock);
        } else {
            viewModel.searchSales(searchType.toUpperCase(), searchValue, startDate, endDate, stock);
        }
    }

    private void observeViewModel() {
        viewModel.getSales().observe(this, sales -> adapter.setSales(sales));

        viewModel.getTotalSales().observe(this, total ->
                binding.totalSalesInput.setText(String.format(Locale.getDefault(), "%.2f", total)));

        viewModel.getTotalTax().observe(this, tax ->
                binding.totalTaxInput.setText(String.format(Locale.getDefault(), "%.2f", tax)));
    }
}