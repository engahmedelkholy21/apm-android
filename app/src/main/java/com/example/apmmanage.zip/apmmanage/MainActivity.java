package com.example.apmmanage;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    Connection con;
    String Connection_result = "";

    // Define a constant for the permission request
    private static final int ALL_PERMISSIONS_REQUEST = 200;

    // Define an array of all the permissions your app requires
    private final String[] requiredPermissions = {
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.CAMERA,
            Manifest.permission.INTERNET,

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check and request permissions when needed
        requestAppPermissions();

        Button btn_Get = findViewById(R.id.idBtnLogin);
       // TextView t = findViewById(R.id.idTVHeader);
        //TextView result_txt = findViewById(R.id.idTVResult);
        EditText pw_txt = findViewById(R.id.pw_txt);

        final String[] retrieved_password = new String[1];
        btn_Get.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ConnectionHelper co = new ConnectionHelper();
                    con = co.conclass();

                    if (con != null) {
                        EditText user_name_txt = findViewById(R.id.un_txt);
                        String query = "SELECT  * FROM user_previliges WHERE user_name = '"
                                + user_name_txt.getText().toString() + "'";

                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(query);

                        while (rs.next()) {
                            retrieved_password[0] = rs.getString(2);
                        }

                    } else {
                        Connection_result = "check connection";
                    }

                    if (pw_txt.getText().toString().equals(retrieved_password[0])) {
//                        result_txt.setTextColor(Color.GREEN);
//                        result_txt.setText("برجاء الانتظار");
                        
                        pw_txt.setText("");
                        Intent i = new Intent(getApplicationContext(), Home_page.class);
                        startActivity(i);
//                        result_txt.setTextColor(Color.WHITE);
//                        result_txt.setText("result");

                    } else {
                        Toast.makeText(MainActivity.this, "تأكد من البيانات", Toast.LENGTH_LONG).show();


                    }
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }



    // Check if all the required permissions are granted
    private boolean arePermissionsGranted() {
        for (String permission : requiredPermissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    // Request all the required permissions
    private void requestPermissions() {
        ActivityCompat.requestPermissions(
                this,
                requiredPermissions,
                ALL_PERMISSIONS_REQUEST
        );
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == ALL_PERMISSIONS_REQUEST) {
            boolean allPermissionsGranted = true;

            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (!allPermissionsGranted) {
                // Inform the user that some permissions were not granted
                Toast.makeText(this, "Permissions not granted!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Example usage in your code
    private void requestAppPermissions() {
        if (!arePermissionsGranted()) {
            // Request all the required permissions
            requestPermissions();
        }
    }
}
