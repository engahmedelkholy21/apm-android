package com.example.apmmanage;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.apmmanage.R;
import com.example.apmmanage.SalesAdapter;
import com.example.apmmanage.databinding.ActivityAllSalesBinding;
import com.example.apmmanage.DateUtils;
import com.example.apmmanage.SalesViewModel;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AllSalesActivity extends AppCompatActivity {
    private ActivityAllSalesBinding binding;
    private SalesViewModel viewModel;
    private SalesAdapter adapter;
    private Date startDate = new Date();
    private Date endDate = new Date();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAllSalesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setupViewModel();
        setupRecyclerView();
        setupSpinner();
        setupDatePickers();
        setupSearchListener();
        observeViewModel();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(SalesViewModel.class);
    }

    private void setupRecyclerView() {
        adapter = new SalesAdapter();
        binding.salesRecyclerView.setAdapter(adapter);
        binding.salesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupSpinner() {
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Date Range", "Customer", "Product", "Category"});
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.searchTypeSpinner.setAdapter(spinnerAdapter);

        binding.searchTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateSearchVisibility(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void updateSearchVisibility(int position) {
        boolean isDateRange = position == 0;
        binding.searchInputLayout.setVisibility(isDateRange ? View.GONE : View.VISIBLE);
        binding.startDateLayout.setVisibility(View.VISIBLE);
        binding.endDateLayout.setVisibility(View.VISIBLE);
    }

    private void setupDatePickers() {
        binding.startDateInput.setOnClickListener(v -> showDatePicker(true));
        binding.endDateInput.setOnClickListener(v -> showDatePicker(false));

        // Set initial dates
        binding.startDateInput.setText(DateUtils.formatDate(startDate));
        binding.endDateInput.setText(DateUtils.formatDate(endDate));
    }

    private void setupSearchListener() {
        binding.searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch();
                return true;
            }
            return false;
        });
    }

    private void showDatePicker(boolean isStartDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(isStartDate ? startDate : endDate);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(year, month, dayOfMonth);

                    if (isStartDate) {
                        startDate = selectedDate.getTime();
                        binding.startDateInput.setText(DateUtils.formatDate(startDate));
                    } else {
                        endDate = selectedDate.getTime();
                        binding.endDateInput.setText(DateUtils.formatDate(endDate));
                    }

                    performSearch();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void performSearch() {
        String searchType = binding.searchTypeSpinner.getSelectedItem().toString();
        String searchValue = binding.searchInput.getText().toString();
        String stock = "DEFAULT_STOCK"; // Replace with actual stock selection

        if (searchType.equals("Date Range")) {
            viewModel.loadSalesByDateRange(startDate, endDate, stock);
        } else {
            viewModel.searchSales(searchType.toUpperCase(), searchValue, startDate, endDate, stock);
        }
    }

    private void observeViewModel() {
        viewModel.getSales().observe(this, sales -> {
            adapter.setSales(sales);
            //updateTotals(sales);
        });

        viewModel.getTotalSales().observe(this, total ->
                binding.totalSalesInput.setText(String.format(Locale.getDefault(), "%.2f", total)));

        viewModel.getTotalTax().observe(this, tax ->
                binding.totalTaxInput.setText(String.format(Locale.getDefault(), "%.2f", tax)));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}