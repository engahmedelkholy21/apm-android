package com.example.apmmanage;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.apmmanage.Sale;
import com.example.apmmanage.SalesRepository;
import java.util.Date;
import java.util.List;

public class SalesViewModel extends ViewModel {
    private final SalesRepository repository;
    private final MutableLiveData<List<Sale>> salesList = new MutableLiveData<>();
    private final MutableLiveData<Double> totalSales = new MutableLiveData<>();
    private final MutableLiveData<Double> totalTax = new MutableLiveData<>();

    public SalesViewModel() {
        repository = new SalesRepository();
    }

    public LiveData<List<Sale>> getSales() {
        return salesList;
    }

    public LiveData<Double> getTotalSales() {
        return totalSales;
    }

    public LiveData<Double> getTotalTax() {
        return totalTax;
    }

    public void loadSalesByDateRange(Date startDate, Date endDate, String stock) {
        List<Sale> sales = repository.getSalesByDateRange(startDate, endDate, stock);
        salesList.setValue(sales);
        calculateTotals(sales);
    }

    public void searchSales(String searchType, String searchValue, Date startDate, Date endDate, String stock) {
        List<Sale> sales = repository.searchSales(searchType, searchValue, startDate, endDate, stock);
        salesList.setValue(sales);
        calculateTotals(sales);
    }

    private void calculateTotals(List<Sale> sales) {
        double salesTotal = 0;
        double taxTotal = 0;

        for (Sale sale : sales) {
            salesTotal += sale.getSellPrice();
            taxTotal += sale.getTax();
        }

        totalSales.setValue(salesTotal);
        totalTax.setValue(taxTotal);
    }
}