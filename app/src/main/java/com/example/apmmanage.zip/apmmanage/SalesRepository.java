package com.example.apmmanage;

import android.util.Log;
import com.example.apmmanage.sql_connect_method;
import com.example.apmmanage.Sale;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SalesRepository {
    private final ConnectionHelper connectionHelper;

    public SalesRepository() {
        this.connectionHelper = new ConnectionHelper();
    }


    public List<Sale> getSalesByDateRange(Date startDate, Date endDate, String stock) {
        List<Sale> sales = new ArrayList<>();
        String query = "SELECT * FROM sales_table WHERE sales_date BETWEEN ? AND ? AND sales_pro_stock = ?";

        try (Connection conn = connectionHelper.conclass();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDate(1, new java.sql.Date(startDate.getTime()));
            stmt.setDate(2, new java.sql.Date(endDate.getTime()));
            stmt.setString(3, stock);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Sale sale = new Sale();
                sale.setId(rs.getInt("sales_id"));
                sale.setDate(rs.getDate("sales_date"));
                sale.setCustomerName(rs.getString("sales_cst_name"));
                sale.setProductId(rs.getString("sales_product_ID"));
                sale.setProductName(rs.getString("sales_product_name"));
                sale.setProductCount(rs.getInt("sales_product_count"));
                sale.setUnitPrice(rs.getDouble("sales_unit_price"));
                sale.setSellPrice(rs.getDouble("sales_price_for_sell"));
                sale.setTax(rs.getDouble("sales_dariba"));
                sale.setCategory(rs.getString("sales_pro_category"));
                sale.setStock(rs.getString("sales_pro_stock"));
                sales.add(sale);
            }
        } catch (Exception e) {
            Log.e("SalesRepository", "Error fetching sales: " + e.getMessage());
        }

        return sales;
    }

    public List<Sale> searchSales(String searchType, String searchValue, Date startDate, Date endDate, String stock) {
        List<Sale> sales = new ArrayList<>();
        String query = "";

        switch (searchType) {
            case "CUSTOMER":
                query = "SELECT * FROM sales_table WHERE sales_cst_name LIKE ? AND sales_date BETWEEN ? AND ? AND sales_pro_stock = ?";
                break;
            case "PRODUCT":
                query = "SELECT * FROM sales_table WHERE sales_product_name LIKE ? AND sales_date BETWEEN ? AND ? AND sales_pro_stock = ?";
                break;
            case "CATEGORY":
                query = "SELECT * FROM sales_table WHERE sales_pro_category = ? AND sales_date BETWEEN ? AND ? AND sales_pro_stock = ?";
                break;
        }

        try (Connection conn = connectionHelper.conclass();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, "%" + searchValue + "%");
            stmt.setDate(2, new java.sql.Date(startDate.getTime()));
            stmt.setDate(3, new java.sql.Date(endDate.getTime()));
            stmt.setString(4, stock);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Sale sale = new Sale();
                // Populate sale object as above
                sales.add(sale);
            }
        } catch (Exception e) {
            Log.e("SalesRepository", "Error searching sales: " + e.getMessage());
        }

        return sales;
    }
}