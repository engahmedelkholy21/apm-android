package com.example.apmmanage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.apmmanage.R;
import com.example.apmmanage.Sale;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class SalesAdapter extends RecyclerView.Adapter<SalesAdapter.SaleViewHolder> {
    private List<Sale> sales;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    public void setSales(List<Sale> sales) {
        this.sales = sales;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public SaleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_sale, parent, false);
        return new SaleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SaleViewHolder holder, int position) {
        Sale sale = sales.get(position);
        holder.bind(sale);
    }

    @Override
    public int getItemCount() {
        return sales != null ? sales.size() : 0;
    }

    static class SaleViewHolder extends RecyclerView.ViewHolder {
        private final TextView saleIdText;
        private final TextView dateText;
        private final TextView customerText;
        private final TextView productText;
        private final TextView priceText;

        public SaleViewHolder(@NonNull View itemView) {
            super(itemView);
            saleIdText = itemView.findViewById(R.id.saleIdText);
            dateText = itemView.findViewById(R.id.dateText);
            customerText = itemView.findViewById(R.id.customerText);
            productText = itemView.findViewById(R.id.productText);
            priceText = itemView.findViewById(R.id.priceText);
        }

        public void bind(Sale sale) {
            saleIdText.setText(String.valueOf(sale.getId()));
            dateText.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(sale.getDate()));
            customerText.setText(sale.getCustomerName());
            productText.setText(sale.getProductName());
            priceText.setText(String.format(Locale.getDefault(), "%.2f", sale.getSellPrice()));
        }
    }
}