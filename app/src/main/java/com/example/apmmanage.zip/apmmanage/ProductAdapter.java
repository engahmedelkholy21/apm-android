package com.example.apmmanage;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {
    private List<PricingInvoiceItem> items;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onDeleteClick(PricingInvoiceItem item);
        void onQuantityChange(PricingInvoiceItem item, int newQuantity);
    }

    public ProductAdapter(List<PricingInvoiceItem> items, OnItemClickListener listener) {
        this.items = items != null ? items : new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_product, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PricingInvoiceItem item = items.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView productNameTv;
        private EditText quantityEt;
        private TextView priceTv;
        private TextView totalTv;
        private ImageButton deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productNameTv = itemView.findViewById(R.id.productNameTv);
            quantityEt = itemView.findViewById(R.id.quantityEt);
            priceTv = itemView.findViewById(R.id.priceTv);
            totalTv = itemView.findViewById(R.id.totalTv);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);
        }

        public void bind(final PricingInvoiceItem item) {
            if (item != null && item.getProduct() != null) {
                productNameTv.setText(item.getProduct().getName());
                quantityEt.setText(String.valueOf(item.getQuantity()));
                priceTv.setText(String.format("%.2f", item.getUnitPrice()));
                totalTv.setText(String.format("%.2f", item.getTotal()));

                deleteBtn.setOnClickListener(v -> {
                    if (listener != null) {
                        listener.onDeleteClick(item);
                    }
                });

                quantityEt.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {}

                    @Override
                    public void afterTextChanged(Editable s) {
                        try {
                            int newQuantity = Integer.parseInt(s.toString());
                            if (newQuantity > 0 && listener != null) {
                                listener.onQuantityChange(item, newQuantity);
                            }
                        } catch (NumberFormatException e) {
                            quantityEt.setText("1");
                        }
                    }
                });
            }
        }
    }
}