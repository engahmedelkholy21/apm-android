package com.example.apmmanage;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.apmmanage.Customer;
import com.example.apmmanage.Product;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PricingActivity extends AppCompatActivity {
    private EditText customerCodeEt, customerNameEt, customerPhoneEt, customerAddressEt;
    private EditText productNameEt, quantityEt, discountEt;
    private TextView subtotalTv, totalTv;
    private Button addProductBtn, saveInvoiceBtn;
    private ImageButton scanBarcodeBtn;
    private RecyclerView productsRecyclerView;

    private ProductAdapter productAdapter;
    private List<PricingInvoiceItem> invoiceItems;
    private ConnectionHelper connectionHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pricing);

        initializeViews();
        setupRecyclerView();
        setupListeners();

        connectionHelper = new ConnectionHelper();
        invoiceItems = new ArrayList<>();
    }

    private void initializeViews() {
        customerCodeEt = findViewById(R.id.customerCodeEt);
        customerNameEt = findViewById(R.id.customerNameEt);
        customerPhoneEt = findViewById(R.id.customerPhoneEt);
        customerAddressEt = findViewById(R.id.customerAddressEt);
        productNameEt = findViewById(R.id.productNameEt);
        quantityEt = findViewById(R.id.quantityEt);
        discountEt = findViewById(R.id.discountEt);
        subtotalTv = findViewById(R.id.subtotalTv);
        totalTv = findViewById(R.id.totalTv);
        addProductBtn = findViewById(R.id.addProductBtn);
        saveInvoiceBtn = findViewById(R.id.saveInvoiceBtn);
        scanBarcodeBtn = findViewById(R.id.scanBarcodeBtn);
        productsRecyclerView = findViewById(R.id.productsRecyclerView);

        quantityEt.setText("1");
        discountEt.setText("0");
    }

    private void setupRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        productsRecyclerView.setLayoutManager(layoutManager);

        productAdapter = new ProductAdapter(invoiceItems, new ProductAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(PricingInvoiceItem item) {
                invoiceItems.remove(item);
                productAdapter.notifyDataSetChanged();
                updateTotals();
            }

            @Override
            public void onQuantityChange(PricingInvoiceItem item, int newQuantity) {
                if (newQuantity > 0) {
                    item.setQuantity(newQuantity);
                    updateTotals();
                    productAdapter.notifyDataSetChanged();
                }
            }
        });

        productsRecyclerView.setAdapter(productAdapter);
    }

    private void setupListeners() {
        customerCodeEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    loadCustomerData(s.toString());
                }
            }
        });

        addProductBtn.setOnClickListener(v -> addProduct());
        saveInvoiceBtn.setOnClickListener(v -> saveInvoice());

        scanBarcodeBtn.setOnClickListener(v -> {
            IntentIntegrator integrator = new IntentIntegrator(this);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
            integrator.setPrompt("Scan product barcode");
            integrator.setCameraId(0);
            integrator.setBeepEnabled(true);
            integrator.setBarcodeImageEnabled(true);
            integrator.initiateScan();
        });

        discountEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                updateTotals();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null && result.getContents() != null) {
            String scannedCode = result.getContents();
            productNameEt.setText(scannedCode);
            addProduct();
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void loadCustomerData(String customerCode) {
        Connection connection = null;
        try {
            connection = connectionHelper.conclass();
            String query = "SELECT * FROM customers WHERE cst_ID = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, customerCode);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                customerNameEt.setText(rs.getString("cst_name"));
                customerPhoneEt.setText(rs.getString("cst_phone"));
                customerAddressEt.setText(rs.getString("cst_address"));
            }
        } catch (SQLException e) {
            Toast.makeText(this, "Error loading customer: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private void addProduct() {
        String productCode = productNameEt.getText().toString().trim();
        if (productCode.isEmpty()) {
            Toast.makeText(this, "Please enter product code", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if product already exists in invoice
        for (PricingInvoiceItem existingItem : invoiceItems) {
            if (existingItem.getProduct().getInternationalCode().equals(productCode)) {
                int currentQty = existingItem.getQuantity();
                int additionalQty = Integer.parseInt(quantityEt.getText().toString());
                existingItem.setQuantity(currentQty + additionalQty);
                productAdapter.notifyDataSetChanged();
                updateTotals();
                clearProductInputs();
                return;
            }
        }

        // If product doesn't exist, fetch and add new item
        Connection connection = null;
        try {
            connection = connectionHelper.conclass();
            String query = "SELECT * FROM products_table WHERE pro_int_code = ? OR pro_name = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, productCode);
            stmt.setString(2, productCode);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Product product = new Product();
                product.setInternationalCode(rs.getString("pro_int_code"));
                product.setName(rs.getString("pro_name"));
                product.setSellingPrice(rs.getDouble("pro_bee3"));
                double bee3=product.setSellingPrice(rs.getDouble("pro_bee3"));

                product.setStock(rs.getString("pro_stock"));
                String stock= product.setStock(rs.getString("pro_stock"));
                int quantity = Integer.parseInt(quantityEt.getText().toString());

                PricingInvoiceItem item = new PricingInvoiceItem(product, quantity,bee3,stock);
                invoiceItems.add(item);
                productAdapter.notifyDataSetChanged();
                updateTotals();
                clearProductInputs();

                // Scroll to the newly added item
                productsRecyclerView.post(() -> {
                    productsRecyclerView.smoothScrollToPosition(invoiceItems.size() - 1);
                });
            } else {
                Toast.makeText(this, "Product not found", Toast.LENGTH_SHORT).show();
            }
        } catch (SQLException e) {
            Toast.makeText(this, "Error adding product: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void clearProductInputs() {
        productNameEt.setText("");
        quantityEt.setText("1");
        productNameEt.requestFocus();
    }

    private void updateTotals() {
        double subtotal = 0;
        for (PricingInvoiceItem item : invoiceItems) {
            subtotal += item.getTotal();
        }

        double discount = 0;
        try {
            discount = Double.parseDouble(discountEt.getText().toString());
        } catch (NumberFormatException e) {
            discountEt.setText("0");
        }

        double total = subtotal - discount;

        subtotalTv.setText(String.format("%.2f", subtotal));
        totalTv.setText(String.format("%.2f", total));
    }

    private void saveInvoice() {
        if (invoiceItems.isEmpty()) {
            Toast.makeText(this, "Please add products first", Toast.LENGTH_SHORT).show();
            return;
        }

        Connection connection = null;
        try {
            connection = connectionHelper.conclass();
            connection.setAutoCommit(false);

            int invoiceId = getNextInvoiceId(connection);
            insertInvoice(connection, invoiceId);
            updateTas3eerNum(connection);

            connection.commit();
            Toast.makeText(this, "Invoice saved successfully", Toast.LENGTH_SHORT).show();
            finish();

        } catch (SQLException e) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            Toast.makeText(this, "Error saving invoice: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(true);
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int getNextInvoiceId(Connection connection) throws SQLException {
        String query = "SELECT MAX(tas3eer_ID) AS next_id FROM Numbers_table WHERE stock = 'الرئيسي'";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("next_id") : 1;
        }
    }

    private void updateTas3eerNum(Connection connection) throws SQLException {
        String query = "UPDATE Numbers_table SET tas3eer_ID = tas3eer_ID + 1 WHERE stock = 'الرئيسي'";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Failed to update tas3eer_ID");
            }
        }
    }

    private void insertInvoice(Connection connection, int invoiceId) throws SQLException {
        String query = "INSERT INTO tas3eer_table (tas3eer_ID, tas3eer_date, tas3eer_cst_name, " +
                "tas3eer_cst_phone, tas3eer_cst_address, tas3eer_discount, tas3eer_product_ID, " +
                "tas3eer_product_name, tas3eer_product_count, tas3eer_unit_price, tas3eer_pro_stock) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            for (PricingInvoiceItem item : invoiceItems) {
                stmt.setInt(1, invoiceId);
                stmt.setDate(2, new java.sql.Date(new Date().getTime()));
                stmt.setString(3, customerNameEt.getText().toString());
                stmt.setString(4, customerPhoneEt.getText().toString());
                stmt.setString(5, customerAddressEt.getText().toString());
                stmt.setDouble(6, Double.parseDouble(discountEt.getText().toString()));
                stmt.setString(7, item.getProduct().getInternationalCode());
                stmt.setString(8, item.getProduct().getName());
                stmt.setInt(9, item.getQuantity());
                stmt.setDouble(10, item.getUnitPrice());
                stmt.setString(11, item.getProduct().getStock());

                stmt.addBatch();
            }
            stmt.executeBatch();
        }
    }
}