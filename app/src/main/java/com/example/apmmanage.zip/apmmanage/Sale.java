package com.example.apmmanage;

import java.util.Date;

public class Sale {
    private int id;
    private Date date;
    private String customerName;
    private String productId;
    private String productName;
    private int productCount;
    private double unitPrice;
    private double sellPrice;
    private double tax;
    private String category;
    private String stock;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getProductCount() { return productCount; }
    public void setProductCount(int productCount) { this.productCount = productCount; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public double getSellPrice() { return sellPrice; }
    public void setSellPrice(double sellPrice) { this.sellPrice = sellPrice; }

    public double getTax() { return tax; }
    public void setTax(double tax) { this.tax = tax; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getStock() { return stock; }
    public void setStock(String stock) { this.stock = stock; }
}