package com.example.apmmanage;

import android.os.AsyncTask;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class get_sales_list extends AsyncTask<String, Void, Map<String, List<Map<String, String>>>> {

    private Connection connect;
    private String connectionResult = "";
    private boolean isSuccess = false;

    @Override
    protected Map<String, List<Map<String, String>>> doInBackground(String... fatoraNum) {
        Map<String, List<Map<String, String>>> salesData = new HashMap<>();

        try {
            ConnectionHelper conStr = new ConnectionHelper();
            connect = conStr.conclass(); // Connect to the database

            if (connect == null) {
                connectionResult = "Check Your Internet Access!";
            } else {
                String query;
                if (fatoraNum[0] == null) {
                    query = "SELECT * FROM sales_table ORDER BY sales_id";
                } else {
                    // Change below query according to your own database.
                    query = "SELECT * FROM products_table WHERE fatora_num = " + fatoraNum[0] + " ORDER BY pro_name";
                }

                Statement stmt = connect.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                while (rs.next()) {
                    String salesId = rs.getString("sales_id");
                    Map<String, String> dataMap = new HashMap<>();
                    dataMap.put("sales_cst_name", rs.getString("sales_cst_name"));
                    dataMap.put("sales_cst_phone", rs.getString("sales_cst_phone"));
                    dataMap.put("sales_cst_address", rs.getString("sales_cst_address"));
                    // dataMap.put("sales_product_ID", rs.getString("sales_product_ID"));
                    dataMap.put("sales_product_name", rs.getString("sales_product_name"));
                    dataMap.put("sales_product_count", rs.getString("sales_product_count"));
                    dataMap.put("sales_unit_price", rs.getString("sales_unit_price"));
                    // dataMap.put("sales_price_for_sell", rs.getString("sales_price_for_sell"));

                    // Check if the sales ID is already in the map
                    if (salesData.containsKey(salesId)) {
                        // If yes, add the product to the existing list
                        salesData.get(salesId).add(dataMap);
                    } else {
                        // If no, create a new list with the product and put it in the map
                        List<Map<String, String>> productList = new ArrayList<>();
                        productList.add(dataMap);
                        salesData.put(salesId, productList);
                    }
                }

                connectionResult = "Successful";
                isSuccess = true;
                connect.close();
            }
        } catch (Exception ex) {
            isSuccess = false;
            connectionResult = ex.getMessage();
        }

        return salesData;
    }
}
